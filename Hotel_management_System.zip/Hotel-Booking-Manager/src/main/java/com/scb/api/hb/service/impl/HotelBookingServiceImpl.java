package com.scb.api.hb.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.scb.api.hb.dto.BookingVO;
import com.scb.api.hb.repository.HotelBookingRepository;
import com.scb.api.hb.service.HotelBookingService;

@Service
@SuppressWarnings({ "unchecked", "rawtypes" })
public class HotelBookingServiceImpl implements HotelBookingService {

	@Autowired
	private HotelBookingRepository bookingRepository;

	@Override
	public List<BookingVO> searchBookingsByName(BookingVO bookingVO){

		return bookingRepository.searchBookingsByName(bookingVO);
	}

	@Override
	public List<BookingVO> getAllBooking() {

		return bookingRepository.getAllBooking();
	}

	@Override
	public BookingVO addBookings(BookingVO bookingVO) {
		return (BookingVO) bookingRepository.addBookings(bookingVO);
	}

	@Override
	public Integer getAvailableRoomCount(BookingVO bookingVO) {
		return bookingRepository.getAvailableRoomCount(bookingVO);
	}
}