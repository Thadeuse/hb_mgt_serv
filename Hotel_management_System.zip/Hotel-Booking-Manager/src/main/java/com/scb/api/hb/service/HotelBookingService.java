package com.scb.api.hb.service;

import java.util.List;

import com.scb.api.hb.dto.BookingVO;

public interface HotelBookingService {

	List<BookingVO> searchBookingsByName(BookingVO bookingVO);

	BookingVO addBookings(BookingVO bookingVO);

	List<BookingVO> getAllBooking();

	Integer getAvailableRoomCount(BookingVO bookingVO);

}