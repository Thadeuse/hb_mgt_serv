package com.scb.api.hb.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.scb.api.hb.constants.DBGeneralConstans;
import com.scb.api.hb.dto.BookingVO;
import com.scb.api.hb.service.HotelBookingService;

@RestController
public class HotelBookingController {

	@Autowired
	private HotelBookingService hotelBookingService;

	@RequestMapping(value = "/list-bookings", method = RequestMethod.GET)
	public ModelAndView showListBookings(ModelMap model) {
		return new ModelAndView("list-bookings");
	}

	@RequestMapping(value = "/add-bookings", method = RequestMethod.GET)
	public ModelAndView addBookings(ModelMap model, BookingVO bookingVO) {
		
		return new ModelAndView("add-bookings");
	}

	@RequestMapping(value = "/add-bookings", method = RequestMethod.POST)
	public ModelAndView addBookings(ModelMap model, BookingVO bookingVO, BindingResult result) {

		if (result.hasErrors()) {
			return new ModelAndView("error");
		}

		BookingVO vo = hotelBookingService.addBookings(bookingVO);

		if (vo != null) {

			if (DBGeneralConstans.SUCCESSFUL.getName().equalsIgnoreCase(vo.getStatus())) {
				return new ModelAndView("success");
			} else if (DBGeneralConstans.NOT_EXITS.getName().equalsIgnoreCase(vo.getStatus())) {
				return new ModelAndView("failed");
			}
		}

		return new ModelAndView("error");
	}

	@RequestMapping(value = "/search-bookings", method = RequestMethod.GET)
	public ModelAndView searchBookings(ModelMap model, BookingVO bookingVO) {
		return new ModelAndView("search-bookings");
	}

	@RequestMapping(value = "/search-bookings-byName", method = RequestMethod.GET)
	public ModelAndView searchBookingsByName(ModelMap model, BookingVO bookingVO) {

		model.put("bookings", hotelBookingService.searchBookingsByName(bookingVO));
		return new ModelAndView("search-booking-result");
	}
	
	@RequestMapping(value = "/search-availability", method = RequestMethod.GET)
	public ModelAndView searchAvailability(ModelMap model, BookingVO bookingVO) {
		return new ModelAndView("search-availability");
	}

	@RequestMapping(value = "/search-availability-byDate", method = RequestMethod.GET)
	public ModelAndView searchBookingsByDate(ModelMap model, BookingVO bookingVO) {

		bookingVO.setAvailableRooms(hotelBookingService.getAvailableRoomCount(bookingVO));
		model.put("bookingVO", bookingVO);
		return new ModelAndView("search-availability-result");
	}
	
	@RequestMapping(value = "/get-available-room-count", method = RequestMethod.GET, 
			consumes = MediaType.APPLICATION_JSON_VALUE, produces = MediaType.APPLICATION_JSON_VALUE)
	public Integer getAvailableRoomCount(@RequestBody BookingVO bookingVO) {

		return hotelBookingService.getAvailableRoomCount(bookingVO);
	}
}
