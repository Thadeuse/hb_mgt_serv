package com.scb.api.hb.dto;

import java.util.Date;

public class BookingVO {

	private String name;
	private String roomNo;
	private String bookingDate;
	private Date createdDate = new Date();
	private Integer availableRooms;
	private String status;

	public BookingVO(String name, String roomNo,
			String bookingDate, 
			Date createdDate) {
		this.name = name;
		this.roomNo = roomNo;
		this.bookingDate = bookingDate;
		this.createdDate = createdDate;
	}

	@Override
	public String toString() {
		return "BookingVO{" + "name='" + name + '\'' 
				+ ", roomNo='" + roomNo + '\'' 
				+ ", bookingDate=" + bookingDate 
				+ ", createdDate=" + createdDate + '}';
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getRoomNo() {
		return roomNo;
	}

	public void setRoomNo(String roomNo) {
		this.roomNo = roomNo;
	}

	public String getBookingDate() {
		return bookingDate;
	}

	public void setBookingDate(String bookingDate) {
		this.bookingDate = bookingDate;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public Integer getAvailableRooms() {
		return availableRooms;
	}

	public void setAvailableRooms(Integer availableRooms) {
		this.availableRooms = availableRooms;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}
}
