package com.scb.api.hb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HotelBookingManagerApplicationTests {

	@Test
	void contextLoads() {
	}

}
