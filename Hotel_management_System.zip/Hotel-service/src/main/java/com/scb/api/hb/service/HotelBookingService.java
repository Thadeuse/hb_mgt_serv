package com.scb.api.hb.service;

import java.util.List;

import org.springframework.http.ResponseEntity;

import com.scb.api.hb.dto.BookingVO;

public interface HotelBookingService {

	ResponseEntity<List<BookingVO>> searchBookingsByName(BookingVO bookingVO);

	ResponseEntity<BookingVO> addBookings(BookingVO bookingVO);

	ResponseEntity<Object> getAllBooking();

	Integer getAvailableRoomCount(BookingVO bookingVO);

}