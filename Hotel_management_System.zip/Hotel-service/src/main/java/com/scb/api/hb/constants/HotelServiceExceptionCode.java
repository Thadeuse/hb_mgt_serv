package com.scb.api.hb.constants;

public enum HotelServiceExceptionCode {

	E01("E01","Error"), 
	E03("E03","Invalid Parameter"),
	E04("E04","Invalid Internal Operation"),
	E05("E04","No Data"), E10("E10","UnAuthorized Access");

	private String code;
	private String message;

	private HotelServiceExceptionCode(String code,String message) {
		
		this.code = code;
		this.message = message;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}
}
