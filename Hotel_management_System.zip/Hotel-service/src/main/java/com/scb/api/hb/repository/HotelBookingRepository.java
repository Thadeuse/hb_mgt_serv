package com.scb.api.hb.repository;

import java.util.List;

import com.scb.api.hb.dto.BookingVO;

@SuppressWarnings("hiding")
public interface HotelBookingRepository<BookingVO, String>{

	List<BookingVO> searchBookingsByName(BookingVO bookingVO);

	BookingVO addBookings(BookingVO bookingVO);

	List<BookingVO> getAllBooking();

	Integer getAvailableRoomCount(BookingVO bookingVO);
}
