package com.scb.api.hb.controller;

import javax.servlet.http.HttpServletRequest;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import com.scb.api.hb.constants.HotelServiceExceptionCode;
import com.scb.api.hb.exception.HotelServiceErrorBean;

@ControllerAdvice
public class GLobalExceptionHandler {

	@ExceptionHandler(Exception.class)
	public ResponseEntity<HotelServiceErrorBean> handleException(HttpServletRequest request, Exception ex) {
		HotelServiceExceptionCode exceptionCode = HotelServiceExceptionCode.E01;
		
		return new ResponseEntity<HotelServiceErrorBean>(new HotelServiceErrorBean(
				exceptionCode.getCode(),exceptionCode.getMessage()),HttpStatus.OK);
	}

}
