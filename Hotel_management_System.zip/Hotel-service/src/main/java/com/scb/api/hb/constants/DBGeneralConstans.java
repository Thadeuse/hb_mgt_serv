package com.scb.api.hb.constants;

import java.util.EnumSet;
import java.util.HashMap;

public enum DBGeneralConstans {

	SUCCESSFUL("SuccessFul"), FAILED("Failed"), 
	ENTRY_ALREADY_EXITS("Entry Already Exits"),
	NOT_EXITS("Room Does not Exits");

	private String constants;

	private static final HashMap<String, DBGeneralConstans> constantsMap = new HashMap<String, DBGeneralConstans>();

	static {
		for (DBGeneralConstans dbconstants : EnumSet.allOf(DBGeneralConstans.class)) {
			constantsMap.put(dbconstants.getName(), dbconstants);
		}
	}

	public static DBGeneralConstans get(String constants) {
		return constantsMap.get(constants);
	}

	private DBGeneralConstans(String constants) {
		this.constants = constants;
	}

	public short shortValue() {
		return (short) ordinal();
	}

	public String getName() {
		return constants;
	}
}
