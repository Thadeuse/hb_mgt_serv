package com.scb.api.hb.repository;

import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.scb.api.hb.constants.DBGeneralConstans;
import com.scb.api.hb.dto.BookingVO;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Repository;

@Repository("hotelRepository")
@SuppressWarnings({ "unchecked", "rawtypes" })
public class InMemHotelRepository implements HotelBookingRepository<BookingVO, String> {

	@Value("${hb.room.count}")
	private String actualRoomCount;

	private Map<String, List<BookingVO>> bookingVOMap;

	public InMemHotelRepository() {
		bookingVOMap = new HashMap<String, List<BookingVO>>();
	}

	@Override
	public List<BookingVO> searchBookingsByName(BookingVO bookingVO) {

		List<BookingVO> bookingVOList = new ArrayList(bookingVOMap.values());

		List<BookingVO> tempBookingVOList = new ArrayList<BookingVO>();

		for (Iterator iterator = bookingVOList.iterator(); iterator.hasNext();) {

			List<BookingVO> bookingVOList1 = (List<BookingVO>) iterator.next();

			for (Iterator iterator2 = bookingVOList1.iterator(); iterator2.hasNext();) {
				BookingVO bookingVO2 = (BookingVO) iterator2.next();

				if (bookingVO.getName().equalsIgnoreCase(bookingVO2.getName())) {
					tempBookingVOList.add(bookingVO2);
				}
			}
		}

		return tempBookingVOList;
	}

	@Override
	public List<BookingVO> getAllBooking() {
		List<BookingVO> bookingVOList = new ArrayList(bookingVOMap.values());

		return bookingVOList;
	}

	@Override
	public synchronized BookingVO addBookings(BookingVO bookingVO) {

		List<BookingVO> bookingVOList = bookingVOMap.get(bookingVO.getBookingDate());

		if (bookingVOList == null) {

			bookingVOList = new ArrayList<BookingVO>();
		}

		int availableRoomCount = getAvailableRoomCount(bookingVOList);
		
		if (availableRoomCount < Integer.parseInt(bookingVO.getRoomNo())) {
			bookingVO.setStatus(DBGeneralConstans.NOT_EXITS.getName());
		} else {
			bookingVO.setCreatedDate(new Date());
			bookingVO.setStatus(DBGeneralConstans.SUCCESSFUL.getName());

			bookingVOList.add(bookingVO);
			bookingVOMap.put(bookingVO.getBookingDate(), bookingVOList);
		}
		
		System.out.println("Room created SuccessFully");

		return bookingVO;
	}

	@Override
	public Integer getAvailableRoomCount(BookingVO bookingVO) {

		List<BookingVO> bookingVOList = bookingVOMap.get(bookingVO.getBookingDate());
		
		return getAvailableRoomCount(bookingVOList);

	}

	private Integer getAvailableRoomCount(List<BookingVO> bookingVOList) {

		if (bookingVOList != null) {

			int roomCount = 0;
			for (Iterator iterator = bookingVOList.iterator(); iterator.hasNext();) {
				BookingVO booVo = (BookingVO) iterator.next();

				roomCount = roomCount + Integer.parseInt(booVo.getRoomNo());
			}

			return Integer.parseInt(actualRoomCount) - roomCount;

		} else {
			return Integer.parseInt(actualRoomCount);
		}
	}
}
