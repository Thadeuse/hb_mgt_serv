package com.scb.api.hb.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.scb.api.hb.dto.BookingVO;
import com.scb.api.hb.repository.HotelBookingRepository;

@Service
@SuppressWarnings({ "unchecked", "rawtypes" })
public class HotelBookingServiceImpl implements HotelBookingService {

	@Autowired
	private HotelBookingRepository bookingRepository;

	@Override
	public ResponseEntity<List<BookingVO>> searchBookingsByName(BookingVO bookingVO){

		return new ResponseEntity(bookingRepository.searchBookingsByName(bookingVO), HttpStatus.OK);
	}

	@Override
	public ResponseEntity<Object> getAllBooking() {

		return new ResponseEntity(bookingRepository.getAllBooking(), HttpStatus.OK);
	}

	@Override
	public synchronized ResponseEntity<BookingVO> addBookings(BookingVO bookingVO) {
		return new ResponseEntity(bookingRepository.addBookings(bookingVO), HttpStatus.OK);
	}

	@Override
	public Integer getAvailableRoomCount(BookingVO bookingVO) {
		return bookingRepository.getAvailableRoomCount(bookingVO);
	}
}