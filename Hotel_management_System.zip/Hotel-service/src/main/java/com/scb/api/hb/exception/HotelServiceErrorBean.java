package com.scb.api.hb.exception;

public class HotelServiceErrorBean {

	private String errorCode;
	private String message;
	private Object object;

	public HotelServiceErrorBean(String errorCode, String message) {
		this(errorCode, message, (Object) null);
	}

	public HotelServiceErrorBean(String errorCode, String message, Object object) {
		this.errorCode = errorCode;
		this.message = message;
		this.object = object;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	public Object getObject() {
		return object;
	}

	public void setObject(Object object) {
		this.object = object;
	}
}
